﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Xamarin_App1.Models
{
    internal class Person
    {

    }
}
