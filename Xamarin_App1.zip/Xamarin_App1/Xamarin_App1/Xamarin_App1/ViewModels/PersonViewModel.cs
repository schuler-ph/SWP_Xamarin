﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;
using Xamarin_App1.Models.common;
using BindingBase = Xamarin_App1.Models.common.BindingBase;

namespace Xamarin_App1.ViewModels
{
    internal class PersonViewModel : BindingBase
    {
        private bool _personDataOK = true;

        private int _personId;
        public int PersonId { 
            get { return this._personId; } 
            set { 
                this._personId = value;
                this.RaisePropertyChanged(nameof(PersonId));
            }
        }

        private string _firstname;
        public string Firstname
        {
            get { return this._firstname; }
            set
            {
                this._firstname = value;
                this.RaisePropertyChanged(nameof(Firstname));
            }
        }

        private string _lastname;
        public string Lastname
        {
            get { return this._lastname; }
            set
            {
                if (value == null || value.Trim().Length < 3)
                {
                    this._personDataOK = false;
                }
                else
                {
                    this._lastname = value;
                    this.RaisePropertyChanged(nameof(Lastname));
                    this._personDataOK = true;
                }
            }
        }

        private string _gender;
        public string Gender
        {
            get { return this._gender; }
            set
            {
                this._gender = value;
                this.RaisePropertyChanged(nameof(Gender));
            }
        }

        private decimal _salary;
        public decimal Salary
        {
            get { return this._salary; }
            set
            {
                this._salary = value;
                this.RaisePropertyChanged(nameof(Salary));
            }
        }

        private DateTime _birthday;
        public DateTime Birthday
        {
            get { return this._birthday; }
            set
            {
                this._birthday = value;
                this.RaisePropertyChanged(nameof(Birthday));
            }
        }


        public ICommand CommandSaveUserData => new Command(SavePersonData, CanSavePersonData);

        private bool CanSavePersonData()
        {
            return this._personDataOK;

            // Firstname, Lastname, Gender, Salary, Birthday
            /*
            if(Firstname == null || Firstname.Length < 3)
            {
                return false;
            }

           

            Gender = Gender.ToLower();
            if (Gender != "male" && Gender != "female")
            {
                return false;
            }

            if (Salary <= 0.0m)
            {
                return false;
            }

            if (Birthday <= new DateTime(1900, 01, 01) || Birthday >= DateTime.Today)
            {
                return false;
            }

            return true;*/
        }

        private void SavePersonData()
        {
            return;
        }
    }
}
